import React, { Component } from 'react';

import { View, Text, TextInput,ToastAndroid,TouchableOpacity,Alert} from 'react-native';

export default class App extends Component{

  constructor (props){
    super(props);
    this.state={
      email : "",
      password : ""
    }

  }
  validate=()=>{
    const {email,password} = this.state
    if(email == ""){
      alert('Email field Can`t be empty')
      return false
    }
    else if(password == ""){
      alert('password field Can`t be empty')
      return false
    }
    else{
      alert('good')
    }
  }



  render(){
    return(
      <View style={{alignSelf:'center'}}>
        <TextInput
        style={{marginTop:20}}
        placeholder={"Email id"}
        onChangeText={email => this.setState({email})}
        />

        <TextInput
        style={{marginTop:20}}
        placeholder={"password"}
        secureTextEntry={true}
        onChangeText={password => this.setState({password})}
        />

        <TouchableOpacity
          onPress={()=> this.validate()}
        >
          <Text>Save</Text>
        </TouchableOpacity>

        <Text>{"email: "+this.state.email}</Text>

      </View>
    );
  }
}