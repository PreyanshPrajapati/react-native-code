import React, { Component } from 'react';
import { StyleSheet, View, Text, Image, TextInput, TouchableOpacity} from 'react-native';
import { createStackNavigator, createAppContainer } from 'react-navigation'; // Version can be specified in package.json


class HomeScreen extends React.Component {
  static navigationOptions = {
    title: 'BooKKar',
  }; 
  render() {
   return (
    <View style={styles.MainContainer}>

        <Text style={{textAlign:"center",marginBottom:5}}>
          Login if already member
        </Text>
                
        <TextInput style = {styles.input}
               underlineColorAndroid = "transparent"
               placeholder = "Email"
               autoCapitalize = "none"/>

        <TextInput style = {styles.input}
               underlineColorAndroid = "transparent"
               placeholder = "Password"
               autoCapitalize = "none"
              //  style={styles.TextInputStyle}
              //   // Making the Text Input Text Hidden.
               secureTextEntry={true}
        />
        <TouchableOpacity
               style = {styles.submitButton}>
               <Text style = {styles.submitButtonText}> Sign In</Text>
        </TouchableOpacity>

        <Text style={styles.heading}>
          -------- OR --------
        </Text>
        <Text style={{textAlign:"center",marginBottom:5}}>
          Register as new member
        </Text>
      <View style={{flex:1,flexDirection:"row"}}>
          <TouchableOpacity style={styles.FacebookStyle} activeOpacity={0.5}>

            <Image 
              source={require('./assets/snack-icon.png')} 
              style={styles.ImageIconStyle} 
              />

            <View style={styles.SeparatorLinefacebook} />

            <Text style={styles.TextStylefacebook}>     Facebook </Text>

          </TouchableOpacity>
          
          
          <TouchableOpacity style={styles.GooglePlusStyle} activeOpacity={0.5}>

            <Image 
              source={require('./assets/snack-icon.png')} 
              style={styles.ImageIconStyle} 
            />

            <View style={styles.SeparatorLinegoogle} />

            <Text style={styles.TextStylegoogle}>     Google </Text>

          </TouchableOpacity>
       </View>
          <TouchableOpacity
               style = {styles.submitButton}>
               <Text style = {{color:"#ffffff"}}> Create New Account</Text>
        </TouchableOpacity>
        
    </View>
   );
 }
}
const RootStack = createStackNavigator(
  {
    Home: HomeScreen,
  },
  {
    initialRouteName: 'Home',
  }
);

const AppContainer = createAppContainer(RootStack);

export default class App extends React.Component {
  render() {
    return <AppContainer />;
  }
}

const styles = StyleSheet.create({

 MainContainer: {
   flex: 1,
   paddingTop: 50,
   backgroundColor: '#FFF',
   
 },
 
 GooglePlusStyle: {
   flexDirection: 'row',
   alignItems: 'center',
   backgroundColor: 'white',
   borderWidth: .5,
   borderColor: 'black',
   height: 40,
   borderRadius: 5 ,
   margin: 10,

},

FacebookStyle: {
  flexDirection: 'row',
  alignItems: 'center',
  backgroundColor: '#485a96',
  borderWidth: .5,
  borderColor: 'black',
  height: 40,
  borderRadius: 5 ,
  margin: 10,

},

ImageIconStyle: {
   padding: 10,
   margin: 5,
   height: 25,
   width: 25,
   resizeMode : 'stretch',

},

TextStylefacebook :{

  justifyContent: 'center',
  color: "#fff",
  marginBottom : 4,
  marginRight :20,
  
},

TextStylegoogle :{

  justifyContent: 'center',
  color: "black",
  marginBottom : 4,
  marginRight :20,
  
},

SeparatorLinefacebook :{

backgroundColor : 'black',
width: 1,
height: 40

},

SeparatorLinegoogle :{

  backgroundColor : 'black',
  width: 1,
  height: 40
  
},

heading: {
  color: '#000',
  fontSize: 16,
  textAlign: 'center',
  marginTop: 5,
  marginBottom: 5 
},
  
input: {
  padding: 5,
  marginTop:10,
  margin: 15,
  height: 40,
  backgroundColor: 'white',
  borderColor: 'black',
  borderWidth: 1
},

submitButton: {
  backgroundColor: '#42B09F',
  padding: 10,
  margin: 15,
  height: 40,
},

});