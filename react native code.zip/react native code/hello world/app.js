import * as React from 'react';

import { Text, View, StyleSheet,TouchableOpacity } from 'react-native';

import { Appbar,TextInput } from 'react-native-paper';

import DatePicker from 'react-native-datepicker';



 class CreateAccPage extends React.Component {

//  static navigationOptions = {
//     title: 'Create Account',
//   };
  

_goBack = () => console.log('Went back');

constructor(props){
    super()
    //set value in state for initial date
    this.state = {
      b_date:"",
      name:'',
      username:'',
      email:'',
      password:'',
      conform_password:''
      }
  }

  validate = () => {
    const { b_date, name, username, email, password, conform_password } = this.state
    const regex_name = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/g ; 
    const regex_username = /^[a-z0-9_-]{3,16}$/g; 

      if(name == ""){
      alert('Name field Can`t be empty');
      // this.setState({Error_name:'your name is requir here'});
      return false
    }

      else if(regex_name.test(name) == false ){ 
        alert('Invalid Name');   
        return false
      }
    
      else if(username == ""){
        alert('Username field Can`t be empty');
        // this.setState({Error_username:'create username '});
        return false
      }

      else if(regex_username.test(username) == false ){ 
        alert('Invalid Username');
        return false   
      }

      // else if (b_date == ''){
      //   alert('Select your birthday')
      // }

      else if(password == ""){
      alert('Password field Can`t be empty');
      // this.setState({Error_password:'create password'});
      return false
    }
      else if(conform_password == ""){
      alert('Conform the password');
      // this.setState({Error_conform_password:'conform the password'});
      return false
    }
      else if(password != conform_password){
        alert('Password and Conform password must be same, try again');
        return false
      }

    else{
      // alert('good');
       this.props.navigation.navigate('Third')
        return true
    }
  }

  render() {
    return (
      <View style={styles.container}>
          
          <TextInput 
            style={styles.input}
            lable="Name"
            placeholder="Enter full name"
            mode="outlined"
            onChangeText={name => this.setState({name})}
          />

          
          <TextInput 
            style={styles.input}
            lable="Username"
            placeholder="Create Username"
            mode="outlined"
            onChangeText={username => this.setState({username})}//this name must be same as variable name
          />

          <View style={{flex:1,flexDirection:"row",marginTop:0,marginBottom:0}}>
            
            <Text style={{marginTop:12,marginLeft:30,fontSize:18}}>
              Date of birth
            </Text>     
                  <DatePicker
                  style={{width: 130,marginLeft:20, marginTop:6}}
                  date={this.state.date} //initial date from state
                  mode="date" //The enum of date, datetime and time
                  placeholder="select date"
                  format="DD-MM-YYYY"
                  minDate="01-01-1930"
                  maxDate="01-01-2012"
                  confirmBtnText="Confirm"
                  cancelBtnText="Cancel"
                  onDateChange={(b_date) => {this.setState({date: b_date})}}
                  />
          </View>

          <View style={{marginBottom:10}}>
              <TextInput 
                style={styles.input}
                lable="Email"
                placeholder="Enter Email ID (Optional)"
                mode="outlined"
                onChangeText={email => this.setState({email})}
              />

              <TextInput 
              style = {styles.input}
                  mode="outlined"
                  placeholder = "Create Password"
                  autoCapitalize = "none"
                  secureTextEntry={true}
                  onChangeText={password => this.setState({password})}
                  />

                <TextInput style = {styles.input}
                  mode="outlined"
                  placeholder = "Conform Password"
                  autoCapitalize = "none"
                  secureTextEntry={true}
                  onChangeText={conform_password => this.setState({conform_password})}
                  />
                <TouchableOpacity
                  style = {styles.submitButton}
                  // onPress = {()=> this.props.navigation.navigate('Third')}
                  onPress = {()=> this.validate()}
                  >
                  <Text style = {{color:"#ffffff",fontSize:20}}> Save and continue</Text>
                </TouchableOpacity>
          </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container:{
    flex:1,
     backgroundColor: '#ffffff',
    },

  input: {
    marginHorizontal:15,
    marginTop:10,
    backgroundColor: 'white',
    borderColor: '#0fb0fa',
    },

  submitButton: {
    backgroundColor: '#42B09F',
    padding: 6,
    marginHorizontal: 40,
    position:'relative',
    alignItems:'center',
    borderRadius:20,
    height:40,
    marginTop:15,
    marginBottom:10
    // height: 40,
},  
});

export default CreateAccPage;
